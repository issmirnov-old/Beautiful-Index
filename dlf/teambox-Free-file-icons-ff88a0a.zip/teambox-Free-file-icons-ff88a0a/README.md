Free Icon Set for files
================================

A free icon set with vector images for popular extensions:
AAC, AI, AIFF, AVI, C, CPP, CSS, DAT, DMG, DOC, EXE, FLV, GIF, H, HPP, HTML,
ICS, JAVA, JPG, KEY, MID, MP3, MP4, MPG, PDF, PHP, PNG, PPT, PSD, PY, QT,
RAR, RB, RTF, SQL, TIFF, TXT, WAV, XLS, XML, YML, ZIP.

All icons are also offered in 512x512px, 48x48px, 32x32px.

These icons are an extract of [Teambox project manager](http://www.teambox.com/ "Project Management").
Design by Saskia Font, at Teambox Technologies S.L. (2009)

Teambox is a collaboration web application built on Ruby on Rails.

Visit [Teambox website](http://www.teambox.com/ "Project Management")
for documentation, community and support: <http://www.teambox.com/>

Teambox: Project Management and Collaboration software
-------

- Website: <http://www.teambox.com/>
- GitHub: <http://github.com/michokest/Teambox>
- Lighthouse tickets: <http://teambox.lighthouseapp.com>
- Original developer: Pablo Villalba (pablo@teambox.com, michokest@gmail.com)
- Copyright: (cc) 2009 Teambox Technologies
- License: GNU AFFERO GENERAL PUBLIC LICENSE

LICENSE
-------

Copyright (C) 2009. Pablo Villalba Villar

Copyright (C) 2009. Teambox Technologies, S.L.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

